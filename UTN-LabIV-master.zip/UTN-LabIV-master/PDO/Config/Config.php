<?php namespace Config;

define("ROOT", dirname(__DIR__) . "/");
define("DB_HOST", "localhost");
define("DB_NAME", "University");
define("DB_USER", "root");
define("DB_PASS", "");
?>




