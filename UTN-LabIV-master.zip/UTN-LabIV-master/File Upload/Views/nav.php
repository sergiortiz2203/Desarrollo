<nav class="navbar navbar-expand-lg  navbar-dark bg-dark">
     <span class="navbar-text">
          <strong>Ejemplo File Upload</strong>
     </span>
     <ul class="navbar-nav ml-auto">
          <li class="nav-item">
               <a class="nav-link" href="<?php echo FRONT_ROOT ?>Image/ShowUploadView">Cargar imagenes</a>
          </li>
          <li class="nav-item">               
               <a class="nav-link" href="<?php echo FRONT_ROOT ?>Image/ShowListView">Listar imagenes</a>
          </li>
     </ul>
</nav>