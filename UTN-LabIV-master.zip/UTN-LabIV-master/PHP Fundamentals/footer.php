<?php
    echo "<p>Copyright &copy; 2019-" . date("Y") . " Laboratorio IV - UTN Mar del Plata</p>";
?>