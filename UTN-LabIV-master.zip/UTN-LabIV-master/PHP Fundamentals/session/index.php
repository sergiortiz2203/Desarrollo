<html>
    <head>
        <title>Session</title>
    </head>
    <body>
        <form action="login.php" method="post">
            <table>
                <tr>
                    <td>Email</td>
                    <td><input type="text" name="email" placeholder="email" value=""></td>                    
                </tr>
                <tr>
                    <td>Password</td>
                    <td><input type="password" name="password" placeholder="password" value=""></td>
                </tr>                
                <tr>
                    <td colspan="3"><button type="submit">Login</button></td>
                </tr>
            </table>
        </form>
    </body>
</html>